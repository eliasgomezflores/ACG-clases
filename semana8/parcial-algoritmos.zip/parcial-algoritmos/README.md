# **Integrantes**

    - Isaac Erick Huarancca Rivas
    - Elias Gomez Flores
    - Thom Maurick Roman Aguilar

![alt](img/1.png)

![alt](img/2-a.png)

![alt](img/3.png)

![alt](img/4.png)