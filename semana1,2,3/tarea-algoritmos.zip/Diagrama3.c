//Ejercicio 3. Ejercicios propuestos
//3. Genere el siguiente escalado:
#include<windows.h>
#include<GL/glut.h>

void inicio( ){
 glMatrixMode(GL_PROJECTION);//pantalla como una matriz	
 glColor3f(0.0 ,0.8 ,1.0 );
 glLoadIdentity();
 
 gluOrtho2D(0,50,-20,30); //eje XY (x1,x2,y1,y2)
 glClearColor(250.0,250.0,250.0,250.0); // color del fondo de la ventana 

 glMatrixMode(GL_MODELVIEW); 
 glLoadIdentity(); 

}

void pantalla(){
 glClear(GL_COLOR_BUFFER_BIT);//limpiar la ventana


glPushMatrix();

 glBegin(GL_POLYGON);
 glVertex2i(4,10); 
 glVertex2i(5,12); 
 glVertex2i(7,12); 
 glVertex2i(8,10);
 glVertex2f(7,8);
 glVertex2i(5,8);
 glVertex2i(4,10);
glEnd();

glPopMatrix();


glPushMatrix();
glTranslatef(-5.7f,-38.0f,0.0f); //X,Y,Z
glScalef(4,4,1);
glBegin(GL_POLYGON);
 glVertex2i(4,10); 
 glVertex2i(5,12); 
 glVertex2i(7,12); 
 glVertex2i(8,10);
 glVertex2f(7,8);
 glVertex2i(5,8);
 glVertex2i(4,10);
glEnd();

glPopMatrix();

glFlush(); 
	
}

int main(int argc, char *argv[]){
 glutInit(&argc,argv); //inicializar GLUT
 glutCreateWindow("Escala de Ampliacion"); //crea ventana
 glutInitWindowSize(400,200); // tama�o de la ventana
 glutInitWindowPosition(300,100); // posiciona la ventana
 glutInitDisplayMode(GLUT_RGB|GLUT_SINGLE); // colores RGB y Un solo Buffer
 inicio();
 glutDisplayFunc(pantalla);
 glutMainLoop(); // permite que el proceso se repita hasta que el usuario cierre ventana.	
 return EXIT_SUCCESS;
}
