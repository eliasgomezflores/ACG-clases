//Ejercicio 3. Ejercicios propuestos
//3. Genere el siguiente escalado:
#include<windows.h>
#include<GL/glut.h>
#include<iostream>
using namespace std;

void inicio( ){
 glColor3f(0.0 ,0.8 ,1.0 );
 glPointSize(2);//tama�o del punto
 glOrtho(120,-120,120,-120,50,-50); //tama�o de la camARA, EL ANGULO, la lejania
 glClearColor(250.0,250.0,250.0,250.0); // color del fondo de la ventana

}
double x0;
double x1;

double y0;
double y1;



void recta_simple () {
double x,b,y;
double dx, dy, m;
dx = x1 - x0;
dy = y1 - y0;
m = dy/dx;
b = y0 - m*x0;
y = y0;

glBegin(GL_POINTS);
for (x=x0; x<=x1; x++) {
glColor3f(0.5,0.5,1);
glVertex3f(x,y,0);
y = m*x + b; }
glEnd();
glFlush();
}

void recta_dda() {
double x,y;
double dx, dy, m;
dx = x1-x0;
dy = y1-y0;
m = dy/dx;
y = y0;
glBegin(GL_POINTS);
for(x=x0; x<=x1; x++) {
glColor3f(0.5,0.5,1);
glVertex3f(x,y,0);
y += m;
}
glEnd();
glFlush();
}


void recta_punto_medio() {
double dx, dy, dE, dNE, d, x, y;
dx = (x1 - x0); 
dy = (y1- y0);
d = 2*dy - dx;
dE = 2*dy;
dNE = 2*(dy - dx);
x = x0;
y = y0;
glBegin(GL_POINTS);
glColor3f(0.5,0.5,1);
glVertex3f(x,y,0);
glEnd();
while (x<x1) {
if(d<=0){
d += dE;
x++;
} else{
d += dNE;
x++;
y++;
}
glBegin(GL_POINTS);
glColor3f(0.5,0.5,1);
glVertex3f(x,y,0);
glEnd();

}

glFlush();
} 
void pantalla(){
	glPushMatrix();
   double dx;
   recta_simple();
   dx=x1-x0;
   x0=x0+dx;
   x1=x1+dx;
   recta_dda();
   dx=x1-x0;
   x0=x0+dx;
   x1=x1+dx;
   recta_punto_medio();
   glPopMatrix();
}
	

int main(int argc, char *argv[]){
cout<<"**Bienvenidos**\n";
cout<<"ingrese el primer Punto\n";
cout<<"    X0: ";
cin>>x0;
cout<<"    Y0: ";
cin>>y0;
cout<<"ingrese el segundo Punto\n";
cout<<"    X1: ";
cin>>x1;
cout<<"    Y1: ";
cin>>y1;
 glutInit(&argc,argv); //inicializar GLUT
 glutCreateWindow("Escala de Ampliacion"); //crea ventana
 glutInitWindowSize(400,200); // tama�o de la ventana
 glutInitWindowPosition(300,100); // posiciona la ventana
 glutInitDisplayMode(GLUT_RGB|GLUT_SINGLE); // colores RGB y Un solo Buffer
 inicio();
 glutDisplayFunc(pantalla);
 glutMainLoop(); // permite que el proceso se repita hasta que el usuario cierre ventana.	
 return EXIT_SUCCESS;
}
