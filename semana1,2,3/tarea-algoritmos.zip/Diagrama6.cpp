#define _USE_MATH_DEFINES

#include <windows.h>  // For MS Windows
#include <GL/glut.h>  // GLUT, includes glu.h and gl.h
#include <math.h>
#include <cmath>
#include <stdio.h>
#include <iostream>

using namespace std;

void inicio(){
	glRotatef( 180, 0.0f, 0.0f, 1.0f );
	glClearColor(250,250,250,250);	// color de fondo
	glPointSize(3);//tama�o del punto
	glLineWidth(3.f); //tama�o de linea
	glColor3i(250,250,250);//color para pintar
	glOrtho(120,-120,120,-120,50,-50); //tama�o de la camARA, EL ANGULO, la lejania	
}

int N=0; //nro de lados



//declarando variables globales
double Radio;

void poligonoEstrellado(){ 

	//arreglos que almacenen los vertices del poligono
	double x[N];
	double y[N];
	
	int i,j;
	
	for(i=0; i<N; i++){
		x[i]=Radio*cos(2*M_PI*(i+1)/N);
		y[i]=Radio*sin(2*M_PI*(i+1)/N);
	}
	
	glClear(GL_COLOR_BUFFER_BIT); //limpia pantalla con el color que iniciamos anteriormente
	
	
	if(N%2==0){
		glBegin(GL_LINE_LOOP);
		glColor3f(0.1, 0.3, 0.5);//color del punto
		i=0;
		for(j=0;j<(N/2);j++){
			if(i>(N-1)){
				i=i-N;
			}
			glVertex2i(x[i], y[i]);
			i+=4;
		}
		glEnd();
		
		glBegin(GL_LINE_LOOP);
		glColor3f(0.1, 0.3, 0.5);//color del punto
		i=1;
		for(j=0;j<(N/2);j++){
			if(i>(N-1)){
				i=i-N;
			}
			glVertex2i(x[i], y[i]);
			i+=4;
		}
		glEnd();
	}
	else{
		glBegin(GL_LINE_LOOP);
		glColor3f(0.1, 0.3, 0.5);//color del punto
		i=0;
		for(int j=0;j<N;j++){
			if(i>(N-1)){
				i=i-N;
			}
			glVertex2i(x[i], y[i]);
			i+=3;
		}
		glEnd();
	}
	
	
	glFlush(); //muestra y limpia la pantalla o el buffer
}

int main(int argc, char** argv) {
	
	//crear menu
	cout<<"-------BIENVENIDO-------\n";
	cout<<"Ingrese Nro. de Lados (mayor a 4): ";
	cin>>N;
	cout<<"Ingrese el Radio (0-100): ";
	cin>>Radio;
	
	
	
	
	//comandos principales
   	glutInit(&argc, argv);                 // Inicializa GLUT
	glutCreateWindow("POLIGONO ESTRELLADO"); // Crea un titulo
   	glutInitWindowSize(110, 120);   // Set the window's initial width & height
   	glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
   	glutInitDisplayMode(GLUT_RGB|GLUT_SINGLE);
   	inicio();
	glutDisplayFunc(poligonoEstrellado); // invoca una funcion
   	glutMainLoop();           // permite que el proceso se repita hasta que el usuario cierre pantalla
		
   return 0;
}
