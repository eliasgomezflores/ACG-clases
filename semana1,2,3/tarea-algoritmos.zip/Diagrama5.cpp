//Dise�ar la funci�n LINEA (p, q) que permita pintar una l�nea 
//considerando todos los casos (l�nea  vertical, horizontal, 
//oblicua, etc.) utilizando el algoritmo de punto medio. Considerar 
//que p (x0, y0)  y  q (xf, yf) son los puntos inicial y final de la 
//recta respectivamente
#include<GL/glut.h>
#include<iostream>
#include<math.h>
#include<cmath>
#include<stdio.h>

using namespace std;
double xi, yi, xf, yf;
double x, y, dy, dx;

void PintarPixel(int x, int y, int R, int G, int B){
	glBegin(GL_POINTS);
	glColor3f(R, G, B);
	glVertex2d(x, y);
	glEnd();
	glFlush();
	
}


void DDA(int xi, int yi, int xf, int yf){
	int i;
	float x, y, dx, dy, res;
	
	if(abs(xf-xi) >= abs(yf-yi)){
		res = abs(xf - xi);
	}
	else{
		res = abs(yf-yi);
	}
	
	dx = (xf - xi)/res;
	dy = (yf - yi)/res;
	i = 1;
	x = (float)xi;
	y = (float)yi;
	while(i<=res){
		PintarPixel(roundf(x), roundf(y),1,1,0);
		x = x + dx;
		y = y + dy;
		i++;
	}
}

int signo(int num){
	
	int resultado;
	if(num < 0){
		resultado = -1;
	}
	
	if(num > 0){
		resultado = 1;
	}
	
	if(num == 0){
		resultado = 0;
	}
	return(resultado);
}

void Bresenham(int xi, int yi, int xf, int yf){
	float e, dx, dy, temp;
	int s1, s2, intercambio, i, x, y;
	
	x = xi;
	y = yi;
	dx = abs(xf-xi);
	dy = abs(yf-yi);
	s1 = signo(xf-xi);
	s2 = signo(yf-yi);
	
	if(dy>dx){
		temp = dx;
		dx = dy;
		dy = temp;
		intercambio = 1;
	}
	else{
		intercambio = 0;
	}
	e = 2 * dy - dx;
	for(i = 1; i <= dx; i++){
		PintarPixel(x,y,1,0,1);
		if(e >= 0){
			if(intercambio == 1){
				x = x + s1;
			}
			else{
				y = y + s2;
			}
			e = e - (2 * dx);
		}
		if(intercambio == 1){
			y = y + s2;
		}
		else{
			x = x + s1;
		}
		e = e + 2 * dy;
	}
}

void Linea(int xi, int yi, int xf, int yf){
	int op;
	cout << "*******MENU*******" << endl;
	cout << "1. Bresenham (Linea Morada)" << endl;
	cout << "2. Linea por DDA (Linea Amarilla)" << endl;
	cout << "Opcion: "; cin >> op;
	cout << "--------------------"<< endl;
	switch(op){
		case 1:
			Bresenham(xi,yi,xf,yf);
			break;
		case 2:
			DDA(xi,yi,xf,yf);
			break;
		default:
			//system("cls");
			Linea(xi,yi,xf,yf);
			break;
	}
}

void Plano(){
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	gluOrtho2D(0.0, 800.0, 800.0, 0.0);
	glPointSize(3);
	for (int x = 0; x < 800; x++){
		PintarPixel(x,400,1,0,0);
	}
	for(int y = 0; y < 800; y++){
		PintarPixel(400,y,1,0,0);
	}
	glEnd();
	glFlush();
}

void Raton(int btn, int ste, int x, int y){
	if(btn == GLUT_LEFT_BUTTON && ste == GLUT_DOWN){
		xi = x; yi = y;
		//system("CLS");
		cout << "--------------------"<< endl;
		cout << "- Punto inicial: (" << x << "," << y << ")" << endl;
		PintarPixel(x,y,0,0,1);
	}
	if(btn == GLUT_RIGHT_BUTTON && ste == GLUT_DOWN){
		xf = x; yf = y;
		cout << "- Punto final: (" << x << "," << y << ")" << endl;
		cout << endl;
		PintarPixel(x,y,0,0,1);
		Linea(xi,yi,xf,yf);
	}
}

int main(int argc, char** argv) {
	cout << "----------------------BIENVENIDO------------------------"<< endl;
	cout << "--ALGORITMO DE PUNTO MEDIO: LINEA POR DDA Y BRESENHAM--"<< endl;
	cout << "INSTRUCCIONES:"<< endl;
	cout << "Clic IZQUIERDO del mouse en el plano -> Punto inicial de la linea"<< endl;
	cout << "Clic DERECHO del mouse en el plano -> Punto final de la linea"<< endl;
	cout << "--------------------------------------------------------"<< endl;
	cout << endl;
   	glutInit(&argc, argv);                 // Inicializa GLUT
   	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutCreateWindow("LINEA"); // Crea un titulo
   	glutInitWindowSize(800, 800);   // Set the window's initial width & height
   	glutInitWindowPosition(500, 50); // Position the window's initial top-left corner
   	glutMouseFunc(Raton);
   	glutDisplayFunc(Plano);
   	glClearColor(0.0, 0.0, 0.0, 0.0);
	
   	glutMainLoop();           // permite que el proceso se repita hasta que el usuario cierre pantalla
		
   return 0;
}
