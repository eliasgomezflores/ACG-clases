#include <windows.h>  // For MS Windows
#include <GL/glut.h>  // GLUT, includes glu.h and gl.h
#include <math.h>
#include <stdio.h>
#include <iostream>

using namespace std;

void inicio(){
	glRotatef( 180, 0.0f, 0.0f, 1.0f );
	glClearColor(250,250,250,250);	// color de fondo
	glPointSize(3);//tama�o del punto
	glLineWidth(3.f); //tama�o de linea
	glColor3i(250,250,250);//color para pintar
	glOrtho(120,-120,120,-120,50,-50); //tama�o de la camARA, EL ANGULO, la lejania	
}

//declarando variables globales
double X0;
double Y0;
double Radio;

void circunferencia(){ 
	
	double x, y;
	double fin;
	glClear(GL_COLOR_BUFFER_BIT); //limpia pantalla con el color que iniciamos anteriormente
	
	//punto final de X
	fin=X0-Radio;
	
	//punto inicial de X
	x=X0+Radio;
	
	//pintar el punto medio
	glBegin(GL_POINTS); 
	glColor3f(0, 0, 0);//color del punto
	glVertex2f(X0,Y0); 
	glEnd();
	
	//mientras el punto no llegue a su fin va deibujando la circunferencia
	while(x>=fin){
		
		//ecuacion de la circunferencia (x-x0)^2+(y-y0)=r^2
		//pero para todo x hay dos puntos de la circunferencia
		//este es el primer punto
		y=sqrt(Radio*Radio - (x-X0)*(x-X0)) + Y0;
		
		//pintar punto
		glBegin(GL_POINTS); 
		glColor3f(0.1, 0.3, 0.5);//color del punto
		
		//dibuja el primer punto
		glVertex2f(x,y);
		
		//hallando el segundo punto de x
		y=((y-Y0)*-1)+Y0;
		
		//dibuja el segundo punto
		glVertex2f(x,y);
		glEnd();
		
		//incremento de X
		x-=0.0001;
	}
	glFlush(); //muestra y limpia la pantalla o el buffer
}

int main(int argc, char** argv) {
	
	//crear menu
	cout<<"-------BIENVENIDO-------\n";
	cout<<"Ingrese el punto de origen:\n";
	cout<<"	1. X0 (0-110): ";
	cin>>X0;
	cout<<"	2. Y0 (0-120): ";
	cin>>Y0;
	cout<<"\nRadio (0-100): ";
	cin>>Radio;
	
	
	
	
	//comandos principales
   	glutInit(&argc, argv);                 // Inicializa GLUT
	glutCreateWindow("CIRCUNFERENCIA"); // Crea un titulo
   	glutInitWindowSize(110, 120);   // Set the window's initial width & height
   	glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
   	glutInitDisplayMode(GLUT_RGB|GLUT_SINGLE);
   	inicio();
	glutDisplayFunc(circunferencia); // invoca una funcion
   	glutMainLoop();           // permite que el proceso se repita hasta que el usuario cierre pantalla
		
   return 0;
}
