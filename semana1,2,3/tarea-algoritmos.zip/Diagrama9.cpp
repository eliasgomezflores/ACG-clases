#include <windows.h>  // For MS Windows
#include <GL/glut.h>  // GLUT, includes glu.h and gl.h
#include <math.h>
#include <stdio.h>
#include <iostream>

using namespace std;

void inicio(){
	glRotatef( 180, 0.0f, 0.0f, 1.0f );
	glClearColor(250,250,250,250);	// color de fondo
	glPointSize(3);//tama�o del punto
	glLineWidth(3.f); //tama�o de linea
	glColor3i(250,250,250);//color para pintar
	glOrtho(120,-120,120,-120,50,-50); //tama�o de la camARA, EL ANGULO, la lejania	
	
}

//declarando variables globales
double X0;
double Y0;
double Radio;
double Rx;
double Ry;

//primer cuadrante del elipse
void ElipseEnOrigen1(){
	double x, y;
	double pendiente;
	glClear(GL_COLOR_BUFFER_BIT); //limpia pantalla con el color que iniciamos anteriormente
	
	//posicion centrada en los origenes
	//punto inicial
	x=Rx;//60
	y=0;
	
	//pintar punto
			glBegin(GL_POINTS); 
			glColor3f(0.1, 0.3, 0.5);//color del punto
			glVertex2f(0,0);
			glEnd();
	
	//mientras el punto no llegue a su fin va deibujando la circunferencia
	while(y<=Ry){
		pendiente=((-Ry*Ry)*x)/((Rx*Rx)*y);
		
		if(pendiente>-1){
			y=sqrt((Ry*Ry)*(Rx*Rx-x*x)/(Rx*Rx));
			//pintar punto
			glBegin(GL_POINTS); 
			glColor3f(0.1, 0.3, 0.5);//color del punto
			//primer cuadrante
			glVertex2f(x,y);
			//segundo cuadrante
			glVertex2f(x*-1,y);
			//tercer cuadrante
			glVertex2f(x*-1,y*-1);
			//cuarto cuadrante
			glVertex2f(x,y*-1);
			glEnd();
			
			x-=0.0001;
			
			if(x<0){
				y=Ry+1;
			}
			
		}
		else{
			x=sqrt((Rx*Rx)*(Ry*Ry-y*y)/(Ry*Ry));
			//pintar punto
			glBegin(GL_POINTS); 
			glColor3f(0.1, 0.3, 0.5);//color del punto
			
			//primer cuadrante
			glVertex2f(x,y);
			//segundo cuadrante
			glVertex2f(x*-1,y);
			//tercer cuadrante
			glVertex2f(x*-1,y*-1);
			//cuarto cuadrante
			glVertex2f(x,y*-1);
			glEnd();	
			
		
		//incremento de X
		y+=0.0001;	
		}	
			
	}
	glFlush(); //muestra y limpia la pantalla o el buffer
}

//primer cuadrante del elipse
void ElipseEnOrigen2(){
	double x, y;
	double pendiente;
	glClear(GL_COLOR_BUFFER_BIT); //limpia pantalla con el color que iniciamos anteriormente
	
	//posicion centrada en los origenes
	//punto inicial
	x=0;
	y=Ry;//20
	
	//punto centro
			glBegin(GL_POINTS); 
			glColor3f(0.1, 0.3, 0.5);//color del punto
			glVertex2f(0,0);
			glEnd();
	
	//mientras el punto no llegue a su fin va deibujando la circunferencia
	while(x<=Rx){
		pendiente=((-Ry*Ry)*x)/((Rx*Rx)*y);
		
		if(pendiente<-1){
			x=sqrt((Rx*Rx)*(Ry*Ry-y*y)/(Ry*Ry));
			//pintar punto
			glBegin(GL_POINTS); 
			glColor3f(0.1, 0.3, 0.5);//color del punto
			//primer cuadrante
			glVertex2f(x,y);
			//segundo cuadrante
			glVertex2f(x*-1,y);
			//tercer cuadrante
			glVertex2f(x*-1,y*-1);
			//cuarto cuadrante
			glVertex2f(x,y*-1);
			glEnd();
			
			y-=0.0001;
			
			if(y<0){
				x=Rx+1;
			}
			
		}
		else{
			y=sqrt((Ry*Ry)*(Rx*Rx-x*x)/(Rx*Rx));
			//pintar punto
			glBegin(GL_POINTS); 
			glColor3f(0.1, 0.3, 0.5);//color del punto
			
			//primer cuadrante
			glVertex2f(x,y);
			//segundo cuadrante
			glVertex2f(x*-1,y);
			//tercer cuadrante
			glVertex2f(x*-1,y*-1);
			//cuarto cuadrante
			glVertex2f(x,y*-1);
			glEnd();	
			
		
		//incremento de X
		x+=0.0001;	
		}	
			
	}
	glFlush(); //muestra y limpia la pantalla o el buffer
}


void elipse(){
	glPushMatrix(); 
	glTranslated(X0,Y0,0.0); 
	if(Ry>=Rx){
		ElipseEnOrigen1();
	} else{
		ElipseEnOrigen2();
	}
	
	glPopMatrix();
}

int main(int argc, char** argv) {
	
	//crear menu
	cout<<"-------BIENVENIDO-------\n";
	cout<<"Ingrese el punto de origen:\n";
	cout<<"	1. X0 (0-110): ";
	cin>>X0;
	cout<<"	2. Y0 (0-120): ";
	cin>>Y0;
	cout<<"\nIngrese el radio: \n";
	cout<<"	1. Rx (0-100): ";
	cin>>Rx;
	cout<<"	2. Ry (0-100): ";
	cin>>Ry;
	
	//comandos principales
   	glutInit(&argc, argv);                 // Inicializa GLUT
	glutCreateWindow("ELIPSE"); // Crea un titulo
   	glutInitWindowSize(600, 450);   // Set the window's initial width & height
   	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)-640)/2,(glutGet(GLUT_SCREEN_HEIGHT)-480)/2); // Position the window's initial top-left corner
   	glutInitDisplayMode(GLUT_RGB|GLUT_SINGLE);
   	inicio();
	glutDisplayFunc(elipse); // invoca una funcion
   	glutMainLoop();           // permite que el proceso se repita hasta que el usuario cierre pantalla
		
   return 0;
}
